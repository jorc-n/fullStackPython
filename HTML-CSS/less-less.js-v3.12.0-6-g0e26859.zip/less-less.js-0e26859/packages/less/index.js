module.exports = require('./lib/less-node').default;
