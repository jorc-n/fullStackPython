describe('Benchmark', function() {
  testLessEqualsInDocument();
});
